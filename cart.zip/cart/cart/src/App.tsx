import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import ProductCard from './components/ProductCard';
import Cart from './components/Cart';

interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
}

interface CartItem extends Product {
  quantity: number;
}

const products: Product[] = [
  { id: 1, name: 'Product 1', description: 'Description of product 1', price: 10.0 },
  { id: 2, name: 'Product 2', description: 'Description of product 2', price: 20.0 },
  { id: 3, name: 'Product 3', description: 'Description of product 3', price: 30.0 },
];

const App: React.FC = () => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const handleAddToCart = (product: Product) => {
    setCartItems(prevItems => {
      const existingItem = prevItems.find(item => item.id === product.id);
      if (existingItem) {
        return prevItems.map(item =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      } else {
        return [...prevItems, { ...product, quantity: 1 }];
      }
    });
  };

  const handleRemoveFromCart = (id: number) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== id));
  };

  const handleUpdateQuantity = (id: number, quantity: number) => {
    if (quantity < 1) return;
    setCartItems(prevItems =>
      prevItems.map(item => (item.id === id ? { ...item, quantity } : item))
    );
  };

  const cartCount = cartItems.reduce((count, item) => count + item.quantity, 0);

  return (
    <Router>
      <nav style={{ padding: '1rem', borderBottom: '1px solid black' }}>
        <Link to="/" style={{ marginRight: '1rem' }}>Products</Link>
        <Link to="/cart">Cart ({cartCount})</Link>
      </nav>
      <Routes>
        <Route
          path="/"
          element={
            <div>
              <h1>Product List</h1>
              {products.map(product => (
                <ProductCard key={product.id} product={product} onAddToCart={handleAddToCart} />
              ))}
            </div>
          }
        />
        <Route
          path="/cart"
          element={
            <Cart
              cartItems={cartItems}
              onRemoveFromCart={handleRemoveFromCart}
              onUpdateQuantity={handleUpdateQuantity}
            />
          }
        />
      </Routes>
    </Router>
  );
};

export default App;
