import { LoaderFunctionArgs, useLoaderData } from "react-router-dom";
import { datapropes } from "./Data";
const Datashowing=()=>
{    const data=useLoaderData();
    return(
        <>
        <div>Data Showing</div>
        <div>
            {
                <ul>
                    <li>{data.id}</li>
                    <li>{data.name}</li>
                    <li>{data.data}</li>
                    <li>{data.comment}</li>
                </ul>
            }
        </div>

        </>
    )
}
export default Datashowing;

export const newdata=async({params}:LoaderFunctionArgs)=>
{
    const id=Number(params.id)
 const connect=await fetch('/jsondata.json')
 const output:datapropes[]=await connect.json();

 const data1=output.find((item)=>item.id==id)
 return data1;
 
}