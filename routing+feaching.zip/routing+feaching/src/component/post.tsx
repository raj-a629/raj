import { useEffect, useRef, useState } from "react"
interface datatype{
    userId:number,
    id:number,
    title:string,
    completed:boolean
}

const Post=()=>
{
    //const data:datatype[]=[];

    const [data,setdata]=useState<datatype|undefined>();
    const [isloading,setisloading]=useState(true);
    const [page,setpage]=useState(1);
    let abortref=useRef<AbortController|undefined>(undefined) //for efficiancy 

    useEffect(()=>
    {   
        abortref?.current?.abort()
         
        abortref.current=new AbortController();
        

          setisloading(true);
        fetch(`https://jsonplaceholder.typicode.com/todos/${page}`,{signal:abortref.current?.signal}).then((res)=>
        {
            return res.json() //create promise
        }).then((responce)=>
        {
            console.log(responce)
            setisloading(false)
            setdata(responce);
        })
    },[page])  //call one time becase no dependency
   

   if(isloading)
   {
    return(
        <>
        <div>page loading.....</div>
        </>
    )
   }


    return(
        <>
          <button onClick={()=>{setpage(page+1)}}>click {page}</button>

          <table border={1}>
  {data && (
    <tr>
      <td>{data.userId}</td>
      <td>{data.id}</td>
      <td>{data.title}</td>
      <td>{data.completed}</td>
    </tr>
  )}
</table>

        </>
    )
}

export default Post