import { useLoaderData } from "react-router-dom";
import { NavLink } from "react-router-dom";

export interface datapropes{
id:number,
name: string,
data: string,
comment:string
}

const Data=()=>
{
    const data=useLoaderData<datapropes[]>();
    return(
        <>
        <div>Data page</div>
        <div>
            {
                data.map((item)=>{
                    return(
                        <ul>
                       <NavLink to={`/data/${item.id}`}> <li>{item.id}</li> </NavLink>
                        <li>{item.name}</li>
                        <li>{item.data}</li>
                        <li>{item.comment}</li>
                    </ul>
                    )
                })
            }
        </div>
        
        </>
    )
}

export default Data;
export const datafind=async()=>
{
    const connect=await fetch('/jsondata.json')
    const output=await connect.json();
    return output;
}

