import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { BrowserRouter, createBrowserRouter } from 'react-router-dom'
//npm install --save-dev @types/react-router-dom
//npm install react-router-dom
// npm install react-router-dom && npm install --save-dev @types/react-router-dom
//npm i react-router-dom @types/react-router-dom
   
import Home from './component/Home'
import Data from './component/Data'
import { RouterProvider } from 'react-router-dom'
import { datafind } from './component/Data'
import Datashowing from './component/Datashowing'
import { newdata } from './component/Datashowing'
import Post from './component/post'
const route=createBrowserRouter([{
  path:'/',
  element:<Home/>
},
{
  path:'/data',
  element:<Data/>,
  loader:datafind
},
{
  path:'/data/:id',
  element:<Datashowing/>,
  loader:newdata
}

])

function App() {
  
  return (
    <>
    <Post/>
     <RouterProvider router={route}/>
    </>
  )
}

export default App

